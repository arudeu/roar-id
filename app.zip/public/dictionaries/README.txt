en_US.aff / en_US.dic — Hunspell US English dictionary (SCOWL-based).

Copyright 2000-2011 by Kevin Atkinson, plus the copyrights listed in the SCOWL README.
Permission to use, copy, modify, distribute and sell these word lists, the associated
scripts, the output created from the scripts, and its documentation for any purpose is
hereby granted without fee, provided that the above copyright notice appears in all
copies and that both that copyright notice and this permission notice appear in
supporting documentation. Kevin Atkinson makes no representations about the suitability
of this array for any purpose. It is provided "as is" without express or implied warranty.

Source: http://wordlist.sourceforge.net/
